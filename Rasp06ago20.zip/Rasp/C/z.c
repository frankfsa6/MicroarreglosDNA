#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <pigpio.h>
#include <math.h>
#include "pinesRasp.h"
/*
gcc -Wall -pthread -o x x.c -lpigpio
sudo ./x 0 8000 50 # Dir - Pasos - Vel
*/

int pasos = 0, max;
// Interrumpe programa y redefine for
void IntsZ(int gpio, int level, uint32_t tick)
{
	if (gpioRead(limZ) == 1)
		max = pasos;
	return;
}
//Secuencia de retroceso
void Retroceso(){
	int j;
	if (gpioRead(dirZ) == 0)
		gpioWrite(dirZ,1);
	else
		gpioWrite(dirZ,0);
	for (j=0; j<Ret; j++){
		gpioWrite(pulZ,1);
		gpioDelay(6);
		gpioWrite(pulZ,0);
		gpioDelay(90);
	}
	max -= Ret;
	return;
}	
// Principal de motores
int main(int argc, char *argv[])
{
	int i = 0,auxa, auxs, k, h, p = 0, vel = atoi(argv[3]);
	float contvel, a;
	if (gpioInitialise() < 0 || argc == 1) 
		return -1;
	// Pines configurados
	gpioSetMode(dirZ,PI_OUTPUT);
	gpioSetMode(pulZ,PI_OUTPUT);
	gpioSetMode(limZ,PI_INPUT);
	gpioSetPullUpDown(limZ,PI_PUD_DOWN);
	gpioSetAlertFunc(limZ, IntsZ);
	// Asigna dirección
	if (atoi(argv[1]) == 0)
		gpioWrite(dirZ,0);
	else
		gpioWrite(dirZ,1);
	//Control de velocidad no tan chafa
	contvel=vel*2;
	if (atoi(argv[2])>30000){
		auxa=200;	
		h=10000;			
	}
	else{
		auxa=atoi(argv[2])/100;			
		h=atoi(argv[2])/2;		
	}	
	a=pow(h,2)/(4*(contvel-vel));
	k=atoi(argv[3]);
	auxs=auxa;
	//Inicia secuencia de pasos
	max = atoi(argv[2]);
	for (i=0; i<max; i++){
		gpioWrite(pulZ,1);
		gpioDelay(6);
		gpioWrite(pulZ,0);
		gpioDelay(contvel);
		pasos++;
		if (atoi(argv[2])>30000 && i==h) 
			auxa=atoi(argv[2])-h;
		if (i==(auxa-1)){
			auxa+=auxs;
			p+=auxs;
			contvel=round((pow((p-h),2)+4*a*k)/(4*a));	
		}	
	}
	//Finaliza pasos
	if ( max != atoi(argv[2]) )
		Retroceso();
	printf("%i",max);
	gpioWrite_Bits_0_31_Clear((1<<dirZ)|(1<<pulZ));
	gpioTerminate();
	return 0;
}
