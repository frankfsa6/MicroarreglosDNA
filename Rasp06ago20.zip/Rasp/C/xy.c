#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <pigpio.h>
#include <math.h>
#include "pinesRasp.h"
/*
gcc -Wall -pthread -o xy xy.c -lpigpio -lm
sudo ./xy 0 0 8000 50000 80 # DirX - DirY - PasosX - PasosY - Vel
*/
int PinPul[] = {pulX,pulY};
int PinDir[] = {dirX,dirY};
int PinInt[] = {limX,limY};
int eje[] = {1,1};
int pasosXY[2]={0,0},max[3];
int av=0;

// Interrumpe programa y redefine for
void IntsX(int gpio, int level, uint32_t tick)
{
	if (gpioRead(limX) == 1)
		av = pasosXY[eje[1]];
	max[2] = 0;
	return;
}
// Interrumpe programa y redefine for
void IntsY(int gpio, int level, uint32_t tick)
{
	if (gpioRead(limY) == 1)
		av= pasosXY[eje[1]];
	max[2] = 1;
	return;
}
//Secuencia de retroceso
void Retroceso(int Pin){
	int j;
	if (gpioRead(PinDir[Pin]) == 0)
		gpioWrite(PinDir[Pin],1);
	else
		gpioWrite(PinDir[Pin],0);
	for (j=0; j<Ret; j++){
		gpioWrite(PinPul[Pin],1);
		gpioDelay(6);
		gpioWrite(PinPul[Pin],0);
		gpioDelay(90);
	}
	if (max[2]==0)
		pasosXY[0] -= Ret;
		else
		pasosXY[1] -= Ret;
	return;
}	

// Principal de motores
int main(int argc, char *argv[])
{
	int i, j, e, auxa, auxs, k, h, p = 0, vel= atoi(argv[5])/2;
	float num[2],d,p1=0,p2=0,aux,contvel, a;
	if (gpioInitialise() < 0 || argc == 1) 
		return -1;
	// Pines configurados X , Y
	for (i=0;i<2;i++){
		gpioSetMode(PinDir[i],PI_OUTPUT);
		gpioSetMode(PinPul[i],PI_OUTPUT);
		gpioSetMode(PinInt[i],PI_INPUT);
		gpioSetPullUpDown(PinInt[i],PI_PUD_DOWN);
	// Asigna dirección
	if (atoi(argv[i+1]) == 0)
		gpioWrite(PinDir[i],0);
	else
		gpioWrite(PinDir[i],1);
	}
	gpioSetAlertFunc(limX, IntsX);
	gpioSetAlertFunc(limY, IntsY);
	max[0] = atoi(argv[3]);
	max[1] = atoi(argv[4]);
	
	//Secuencia de pasos para una sola dirección
	if (max[0] == 0 ||  max[1] == 0){
		if (max[0] != 0)
			eje[1]=0;
		av=max[eje[1]];
		vel=vel*2;
		//Control de velocidad 
		contvel=vel*2;
		if (max[eje[1]]>30000){
			auxa=200;	
			h=10000;			
		}
		else{
			auxa=max[eje[1]]/100;			
			h=max[eje[1]]/2;		
		}	
		a=pow(h,2)/(4*(contvel-vel));
		k=vel;
		auxs=auxa;
		for (i=0; i<av; i++){
				gpioWrite(PinPul[eje[1]],1);
				gpioDelay(6);
				gpioWrite(PinPul[eje[1]],0);
				gpioDelay(contvel);
				pasosXY[eje[1]]++;	
				if (max[eje[1]]>30000 && i==h) 
					auxa=max[eje[1]]-h;
				if (i==(auxa-1)){
					auxa+=auxs;
					p+=auxs;
					contvel=round((pow((p-h),2)+4*a*k)/(4*a));	
				}	
		}
	}
	else if (max[0] == max[1]){
		
	//Inicia secuencia de pasos iguales
		//Control de velocidad 
		contvel=vel*2;
		if (max[0]>30000){
			auxa=200;	
			h=10000;			
		}
		else{
			auxa=max[0]/100;			
			h=max[0]/2;		
		}	
		a=pow(h,2)/(4*(contvel-vel));
		k=vel;
		auxs=auxa;
		av=max[0];
		for (i=0; i<av; i++){
				gpioWrite(pulX,1);
				gpioDelay(6);
				gpioWrite(pulX,0);
				gpioDelay(contvel);
				pasosXY[0]++;
				gpioWrite(pulY,1);
				gpioDelay(6);
				gpioWrite(pulY,0);
				gpioDelay(contvel);
				pasosXY[1]++;
				if (max[0]>30000 && i==h) 
					auxa=max[0]-h;
				if (i==(auxa-1)){
					auxa+=auxs;
					p+=auxs;
					contvel=round((pow((p-h),2)+4*a*k)/(4*a));	
				}
		}			
	}
	else {
		
		//Obtiene numero de pasos para la diagonal dif de 45° 
		if (max[0] > max[1])					
			eje[0]=0;
		else 
			eje[1]=0;
		//Si x > y  eje[0]=0, eje [1]=1 
		//Si y > x  eje[0]=1, eje [1]=0
		num[eje[0]]=max[0];
		num[eje[1]]=max[1];
		//num[0] numero mayor y num [1] numero menor
		aux=num[0]/num[1];
		e=trunc(aux);
		d=aux-e;
		aux=0;
		//Control de velocidad 
		if (num[0]>30000){
			auxa=200;	
			h=10000;			
		}
		else{
			auxa=num[0]/100;			
			h=num[0]/2;		
		}	
		contvel=vel*2;
		a=pow(h,2)/(4*(contvel-vel));
		k=vel;
		auxs=auxa;		
		//Secuencia de pasos para diagonales muy pronunciadas
		if (e>2){
			aux=e-2;
			aux=aux*num[1];
			e=2;
			av=aux;
			vel=vel*2;
			for (i=0; i<av; i++){
					gpioWrite(PinPul[eje[0]],1);
					gpioDelay(6);
					gpioWrite(PinPul[eje[0]],0);
					gpioDelay(contvel);
					pasosXY[eje[0]]++;
					if (num[0]>30000 && p==h) 
						auxa=num[0]-h;
					if (i==(auxa-1)){
						auxa+=auxs;
						p+=auxs;
						contvel=round((pow((p-h),2)+4*a*k)/(4*a));	
						printf("%i %0.0f/",p,contvel);
					}					
			}	
			vel=vel/2;
		}
		if (av==aux){
			p1=round(num [1]*d);
			p2=num [1]-p1;		
			aux=1;
			auxa=auxs;			
			//Inicia secuencia de pasos
			av=num[1];
			for (i=0; i<av; i++){
				for (j=0; j<e+aux; j++){
						gpioWrite(PinPul[eje[0]],1);
						gpioDelay(6);
						gpioWrite(PinPul[eje[0]],0);
						gpioDelay(contvel);
						pasosXY[eje[0]]++;
						if (num[0]>30000 && p==h) 
							auxa=num[0]-h;
						if (i==(auxa-1)){
							auxa+=auxs;
							p+=auxs;
							contvel=round((pow((p-h),2)+4*a*k)/(4*a));	
							printf("%i %0.0f/",p,contvel);
						}
				}			
				gpioWrite(PinPul[eje[1]],1);
				gpioDelay(6);
				gpioWrite(PinPul[eje[1]],0);
				gpioDelay(contvel);
				pasosXY[eje[1]]++;
				
				if (i==p1-1)
					aux--;
			}
		}
	}
	printf("%f / %f -- ",p1,p2);
	//Finaliza pasos y espera un tiempo para revisar si hay interrupción
	gpioSleep(PI_TIME_RELATIVE, 0, 200000);
	if ( pasosXY[0] != atoi(argv[3]) || pasosXY[1] != atoi(argv[4]))
		Retroceso(max[2]);
	printf("%i /",pasosXY[0]);
	printf(" %i",pasosXY[1]);
	gpioWrite_Bits_0_31_Clear((1<<dirX)|(1<<pulX));
	gpioWrite_Bits_0_31_Clear((1<<dirY)|(1<<pulY));
	gpioTerminate();
	return 0;
}


/*
 *Basura
 * Pasos por mm : 250
 * Muestras X-Y mm: 4 - 216
 * Muestras X-Y pasos: 1,000 - 54,000
 * Usuario X-Y mm: 300 - 250
 * Usuario X-Y pasos: 75,500 - 62,500
 * Slide X-Y mm: 173 - 10
 * Slide X-Y pasos: 43,250 - 2,500
 * Movimiento prueba: X - 169 mm 42,250 pasos dir 1
 * Movimiento prueba: Y - 206 mm 51,500 pasos dir 0
 * 6 cm en X pasos 12 500
 * 27.5 cm en Y 68 750
 */ 
