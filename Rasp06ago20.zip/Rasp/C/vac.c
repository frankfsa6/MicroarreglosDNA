#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <pigpio.h>
#include "pinesRasp.h"
/*
gcc -Wall -pthread -o vacío vacío.c -lpigpio
sudo ./vacío 0 # Encendido/Apagado
*/

int main(int argc, char *argv[]){
	
	if (gpioInitialise() < 0 || argc == 1) 
		return -1;
	// Pines configurados
	gpioSetMode(bomV,PI_OUTPUT);
	// Asigna estado
	if (atoi(argv[1]) == 0)
		gpioWrite(bomV,0);
	else
		gpioWrite(bomV,1);
		
	//gpioWrite_Bits_0_31_Clear((1<<bomV));
	//gpioTerminate();
	return 0;	
}
