#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <pigpio.h>
#include "pinesRasp.h"
/*
gcc -Wall -pthread -o o o.c -lpigpio -lm
sudo ./o 0 0 0 100 # PosZ - PosX - PosY - Vel
Ret = 1000
*/
int sensor = 0, ints = 0, pinPul = pulZ, pinDir = dirZ;
// Interrumpe programa y redefine for
void IntsXYZ(int gpio, int level, uint32_t tick){
	if (gpioRead(limX) == 1 || gpioRead(limY) == 1 || gpioRead(limZ) == 1 )
		ints = 1;
	return;
}
//Secuencia de retroceso
void Retroceso(){
	int k;
	gpioWrite(pinDir,1);
	for (k=0; k<Ret; k++){
		gpioWrite(pinPul,1);
		gpioDelay(6);
		gpioWrite(pinPul,0);
		gpioSleep(PI_TIME_RELATIVE, 0, VelOrg);
	}
	gpioWrite(pinDir,0);
	return;
}	
// Principal de motores (posZ, posX, posY)
int main(int argc, char *argv[])
{
	int i, j;
	if(gpioInitialise() < 0 || argc == 1) 
		return -1;
	int origen[3] = {atoi(argv[1]),atoi(argv[2]),atoi(argv[3])};
	// Pines configurados X
	gpioSetMode(dirX,PI_OUTPUT);
	gpioSetMode(pulX,PI_OUTPUT);
	gpioSetMode(limX,PI_INPUT);
	gpioSetPullUpDown(limX,PI_PUD_DOWN);
	gpioSetAlertFunc(limX, IntsXYZ);
	// Pines configurados Y
	gpioSetMode(dirY,PI_OUTPUT);
	gpioSetMode(pulY,PI_OUTPUT);
	gpioSetMode(limY,PI_INPUT);
	gpioSetPullUpDown(limY,PI_PUD_DOWN);
	gpioSetAlertFunc(limY, IntsXYZ);
	// Pines configurados Z
	gpioSetMode(dirZ,PI_OUTPUT);
	gpioSetMode(pulZ,PI_OUTPUT);
	gpioSetMode(limZ,PI_INPUT);
	gpioSetPullUpDown(limZ,PI_PUD_DOWN);
	gpioSetAlertFunc(limZ, IntsXYZ);
	// Todos hacia origen
	gpioWrite(dirX,0);
	gpioWrite(dirY,0);
	gpioWrite(dirZ,0);
	//Inicia secuencia de pasos
	for(j=0; j<3; j++){
		for(i=0; i<=1; i++){
			while(ints != 1){
				gpioWrite(pinPul,1);
				gpioDelay(6);
				gpioWrite(pinPul,0);
				gpioSleep(PI_TIME_RELATIVE, 0, VelOrg*1.5);
				origen[j]--;
			}
			if(i==0)
				printf("%i\n", origen[j]+Ret);
			Retroceso();
			sensor++;
			ints = 0;
		}
		if(sensor == 2){
			pinPul = pulX;
			pinDir = dirX;
		}
		else if(sensor == 4){
			pinPul = pulY;
			pinDir = dirY;
		}
	}
	gpioWrite_Bits_0_31_Clear((1<<dirX)|(1<<pulX)|(1<<dirY)|(1<<pulY)|(1<<dirZ)|(1<<pulZ));
	gpioTerminate();
	return 0;
}
