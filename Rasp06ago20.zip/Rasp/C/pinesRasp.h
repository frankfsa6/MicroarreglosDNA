// Pines para pulso, direccion, bomba, sensores y emergencia
#define pulX 27
#define dirX 21
#define pulY 24
#define dirY 18
#define pulZ 23
#define dirZ 22
#define bomV 4
#define limX 12
#define limY 20
#define limZ 19
#define botE 7
// Valores predefinidos
#define Ret 500
#define VelOrg 200
