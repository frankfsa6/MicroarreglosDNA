CREATE USER 'raspberry'@'localhost' IDENTIFIED BY 'microarreglosdna';
GRANT ALL PRIVILEGES ON *.* TO 'raspberry'@'localhost';
FLUSH PRIVILEGES;
