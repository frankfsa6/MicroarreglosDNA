<?php
  // Compila los archivos con gcc
  /*
  $nombre = ["o","x","xy","y","z","vac"];
  for($i = 0; $i<sizeof($nombre); $i++){
    $str = "sudo rm ../C/$nombre[$i] -f 2>&1";
    exec($str, $out, $ret);
    $str = "sudo gcc -Wall -pthread -o ../C/$nombre[$i] ../C/$nombre[$i].c -lpigpio -lm 2>&1";
    exec($str, $out, $ret);
    echo "OUT:";
    var_dump($out);
    echo "----RET:";
    var_dump($ret);
  }
  * */
    //$str = "sudo ../C/x 0 1000 100 2>&1";
    $str = "sudo pkill pigpiod 2>&1";
    exec($str, $out, $ret);
    echo "-----OUT:";
    var_dump($out);
    echo "----RET:";
    $str = "sudo ../C/x 0 1000 100 2>&1";
    exec($str, $out, $ret);
    echo "-----OUT:";
    var_dump($out);
    echo "----RET:";
?>
