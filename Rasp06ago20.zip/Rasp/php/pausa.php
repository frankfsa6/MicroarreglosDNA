<?php
  // Verifica la sesión y asigna valor de pausa
  session_name("IFCLab");
  session_start();
  // Quita/pone pausa o activa paro total
  if( !isset($_POST['consul']) ){
    // Valor "1" es activado, valor "0" es desactivado
    $val = $_POST['pausa'];
    // Tipo "0" en pausa es pausa, "1" es paro total
    $tipo = $_POST['tipo'];
    // Decide entre realizar pausa únicamente o alto total
    // Cambio 1,0 cambiar Placa. Cambio 1,1 cambiar placa y vidrio de limpieza. Cambio 0,0 sin cambios
    if($tipo == 0){
      $_SESSION['Pausa'] = $val;
      echo "Pausa ".$_SESSION['Pausa'].", Cambio ".$_SESSION['Cambio'][0].$_SESSION['Cambio'][1];
    }
    // Solo permite realizar paro total
    else{
      $_SESSION['Fin'] = 2;
      $_SESSION['Pausa'] = 0;
      echo "Fin ".$_SESSION['Pausa'];
    }
  }
  // Mata todo proceso y termina rutina
  elseif($_POST['consul'] == "finPhp"){
    session_destroy(); 
    exec("sudo ps -efw | grep php | grep -v grep | awk '{print $2}' | xargs kill");
    exit();
  }
  // Campo que realiza consulta de fin de rutina o proceso actual
  else{
    $consulta = $_POST['consul'];
    // Comprueba si ya terminó la rutina (2-finalizado, 1-trabajando, 0-algo raro)
    if($consulta == 0)
      echo $_SESSION['Fin'];
    // Pide valores actuales de posición y pausas si ocurren
    else{
      echo $_SESSION['Actual'][0].",".$_SESSION['Actual'][1].",".$_SESSION['Actual'][2].",";
      if( !isset($_SESSION['Cambio']) )
        echo "0,0";
      else
        echo $_SESSION['Cambio'][0].",".$_SESSION['Cambio'][1];
      // Limpia valor de cambio
      $_SESSION['Cambio'] = [0,0];
    }
  }
  session_write_close();
?>
