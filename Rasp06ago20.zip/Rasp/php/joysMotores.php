<?php
  include("ArchC.php");
  // Obtiene datos de sesi�n en campo actual o inicia/finaliza movimiento
  if( isset($_POST['rev']) ){
    session_name("IFCLab");
    session_start();
    $rev = $_POST['rev'];
    // Devuelve datos de movimiento actual
    if( $rev == 0 )
      $str = $_SESSION['JoysPos'];
    // Fija valor de movimiento presionado (1:presionado, 2:liberado)
    else
      $_SESSION['JoysMov'] = $rev;
    session_write_close();
  }
  // Checa pasos en mm, mueve a lugares o activa motores seg�n presione joystick
  else{
    $joystick = new ArchC();
    // Pide datos de los pasos en mm para cuentas
    if( isset($_POST['pasos']) )
      $str = implode( ",", $joystick->LugDB("pasosmm") );
    // Ubica lugares definidos y mueve motores
    elseif( isset($_POST['lug']) ){
      $vel = 70;
      $datos = explode(",",$_POST['lug']);
      // Manda valores de posici�n actual en mm si no est� en esa posici�n
      if( $joystick->joysTemp( $datos[0], floatval($datos[1]), floatval($datos[2]) , floatval($datos[3])) == 0 )
        $joystick->LugarD($datos[0], $vel, $vel, "Lugar");
      // Coordenadas del lugar
      $str = $datos[0].",".implode( ",", $joystick->LugDB($datos[0]) );
    }
    // Mueve motores (eje, direcci�n, posici�n en mm, velocidad)
    elseif( isset($_POST['vel']) ){
      $vel = $_POST['vel']*100;
      $datos = explode(",",$_POST['bot']);
      $str = $joystick->joysMot( $datos[0], $datos[1], floatval($datos[2]) , $vel );
    }
    // Va al origen o calibraci�n
    else{
      $datos = explode(",",$_POST['bot']);
      // Si es primera vez, devuelve ceros
      if( sizeof($datos) == 1 ){
        $joystick->SensarOrigen();
        $str = "Primera vez al sensar origen (no hay pasos perdidos), 0 pasos = 0 &mu;m, 0 pasos = 0 &mu;m, 0 pasos = 0 &mu;m";
      }
      // Devuelve pasos perdidos
      else{
        $pasos = $joystick->SensarOrigen( floatval($datos[1]), floatval($datos[2]), floatval($datos[3]) );
        // Decide encabezado de salida
        if( $datos[0]== "o" )
          $str = "Pasos perdidos al sensar origen ";
        else
          $str = "Distancia recorrida desde el punto solicitado ";
        // Detecta error en medici�n
        if( count($pasos) != 3 )
          for($i=0; $i<3; $i++)
            $str .= ",no fue detectado correctamente el sensor";
        // Manda datos
        else
          for($i=0; $i<3; $i++){
            $pasosM = explode(",", $pasos[$i]);
            $str .= ",".$pasosM[0]." pasos = ".$pasosM[2]." ".$pasosM[1]." ( ".$pasosM[3]." pasos / mm )";
          }
      } 
    }
    unset($joystick);
  }
  // Devuelve datos conseguidos
  echo $str;
?>
