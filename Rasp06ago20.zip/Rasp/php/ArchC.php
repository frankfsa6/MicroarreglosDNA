<?php
  set_time_limit(0);
  include("bd.php");
  // Clase para crear archivos
  class ArchC{
    private $pasos;		//Pasos que se avanzarán en cada caso y se enviarán al archivo C
    private $actual;	//Coordenadas posición actual en mm
    private $slide;		//Coordenadas posición a avanzar en slide en mm
    private $lugares;	//Coordenadas de los lugares obtenidos en mm
    private $zslide;	//Número de milimentros -3mm que baja para poner puntos en el Slide
    // Constructor que fija tipo de archivo e inicializa rutina
    public function __construct(){
      $this->DatosDB();
      $this->FinRutina(1);
    }
    // Lleva motores al origen
    public function SensarOrigen( $mmX = null, $mmY = null, $mmZ = null ){
      // Usado en rutina, no necesita valores de pasos perdidos
      if( $mmX === null && $mmY === null && $mmZ === null ){
        $str = "sudo ../C/o 0 0 0 2>&1";
        exec($str);
        $this->actual = [0,0,0];
        $this->ActualizaMov();
        $mmX = [];
      }
      // Joystick donde el código C sensa primero Z, luego X, finaliza Y, devolviendo pasos en um
      else{
        $pasosDB = $this->LugDB("pasosmm");
        $str = "sudo ../C/o $mmZ $mmX $mmY 2>&1";
        exec($str, $out);
        $mmX = [];
        // Si no recibe 3 lecturas (Z,X,Y), hubo error
        if( count($out) == 3 ){
          for($i=0; $i<3; $i++){
            // Asigna eje correcto y manda milímetros o micrómetros, según pasos
            $eje = ($i == 0)?1:( ($i == 1)?2:0 );
            $out[$eje] = abs( (int)$out[$eje] ); 
            if( $out[$eje] >= 50 )
              $mmX[] = $out[$eje].",mm,".round($out[$eje]/$pasosDB[$i], 3).",".$pasosDB[$i];
            else
              $mmX[] = $out[$eje].",&mu;m,".round(1000*$out[$eje]/$pasosDB[$i]).",".$pasosDB[$i];
          }
        }
      }
      return $mmX;
    }
    // Devuelve coordenadas XYZ desde base de datos del lugar buscado o pasos/mm
    public function LugDB($lug){
      // Lugares iniciales y conexión
      $lugsDB = [0,0,0];
      $conexion = ConectarBD();
      if( $conexion != false ){
        mysqli_set_charset($conexion,"utf8");
        if( $lug == "pasosmm" ){
          // Pide datos de pasos de motor por eje
          mysqli_set_charset($conexion,"utf8");
          $sql = "SELECT id,valor FROM raspberry WHERE tipo != 'gpio'";
          $res = mysqli_query($conexion, $sql);
          if( $res->num_rows !=0 ) {
            // Asigna valores de base
            while ( $dato = mysqli_fetch_assoc($res) )
              $cuentas[$dato['id']] = (float) $dato['valor'];
            mysqli_free_result($res);
            // Realiza cuentas para XYZ
            $ejeBD = ["X","Y","Z"];
            for($i = 0; $i<3; $i++)
              $lugsDB[$i] = round( $cuentas['pasosRev'.$ejeBD[$i]]/$cuentas['tor'.$ejeBD[$i]] , 3);
          }
        } 
        else{
          // Pide datos de lugar buscado
          $sql = "SELECT * FROM config where nombre = '".$lug."'";
          $res = mysqli_query($conexion, $sql);
          if( $res->num_rows !=0 ) {
            $dato = mysqli_fetch_assoc($res);
            $lugsDB = [$dato["x"], $dato["y"], $dato["z"]];
            mysqli_free_result($res);
          }
        }
      }
      return $lugsDB;
    }
    // Permite fijar un lugar sólo para JOYSTICK, NO USAR EN RUTINAS
    public function joysTemp($lug ,$x, $y, $z){
      $act = 0;
      $lugar = $this->LugDB($lug);
      // Si ya se encuentra en esa posición, avisa para no mover joystick
      if( $x == $lugar[0] && $y == $lugar[1] && $z == $lugar[2] )
        $act = 1;
      // Da coordenadas actuales
      else
        $this->actual = [$x, $y, $z];
      return $act;
    }
    // Mueve motores dados por joystick y devuelve final en mm
    public function joysMot($eje ,$dir, $pos, $vel){
      // Valor de pasos/mm y velocidad (mínimo 70 us)
      $pasosDB = $this->LugDB("pasosmm");
      $pasosmm = ($eje == "x")?$pasosDB[0]:( ($eje == "y")?$pasosDB[1]:$pasosDB[2] );
      $vel = 70*$vel;
      // Ejecuta función 
      do{
        session_name("IFCLab");
        session_start();
        $sigue = $_SESSION['JoysMov'];
        $_SESSION['JoysPos'] = $eje.",".$pos;
        session_write_close();
        // Sigue mandando código ejecutable
        if( $sigue == 1 ){
          // Avanza 10 mm y ejecuta pasos con códigos C
          $pasos = round(10*$pasosmm);
          $str = "sudo ../C/$eje $dir $pasos $vel 2>&1";
          exec($str, $out);
          // En caso de no dar pasos, saldrá mensaje y termina
          if( !is_numeric($out[0]) ){
            $msj = "Error interno al mover motor en eje ,".$pos;
            $sigue = 2;
          }
          else{
            // Hubo una interrupción y termina
            if( (int)$out[0] != $pasos ){
              $sigue = 2;
              $msj = "Sensor de límite detectado en eje ,".$pos;
            }
            $pos += ($dir == "0")? round((int)$out[0]/$pasosmm)*(-1) : round((int)$out[0]/$pasosmm);
          }
          // Si ya llegó a cero, termina movimientos
          if( $dir == "0" && $pos == 0){
            $sigue = 2;
            $msj = "No se puede avanzar más en eje ,".$pos;
          }
        }
      }while( $sigue == 1 );
      // Manda última medición de Joystick
      if( !isset($msj) )
        $msj = "Movimientos finalizados en eje ,".$pos;
      // Datos finales en sesión por si jquery es más rápido
      session_name("IFCLab");
      session_start();
      $_SESSION['JoysMov'] = 2;
      $_SESSION['JoysPos'] = $eje.",".$pos;
      session_write_close();
      return $msj;
    }
    // Usa diagonales para lugares principales
    public function LugarD($lugar,$vxy,$vz,$typeZ){
      if($this->FinRutina(0) == 0){
        // Primero sube eje Z para evitar chocar: (2000 pasos/rev)/(8.02mm/rev) = 250 pasos/mm
        if($this->actual[2] != 0 && $typeZ == "Lugar"){
          $pasos = round( $this->actual[2]*$this->pasos[2] );
          // Checa si existen pausas o ejecuta
          $this->Pausas();
          $str = "sudo ../C/z 0 $pasos $vz 2>&1";
          exec($str, $out);
          unset($str,$out, $pasos);
          $this->actual[2] = 0;
        }
        elseif ($this->actual[2] != $this->lugares["Slide"][2] && $typeZ == "Slide"){
          $prox = $this->lugares["Slide"][2];
          $real = $prox-$this->actual[2];
          // Dirección de movimiento
          $dir = ($real > 0)? 1 : 0;
          // Modifica posición actual
          $this->actual[2] += $real;
          // (2000 pasos/rev)/(8.02 mm/rev) = 250 pasos/mm
          $pasos = round(abs($real)*$this->pasos[2]);
          $this->Pausas();
          $str = "sudo ../C/z $dir $pasos $vz 2>&1";
          exec($str, $out);
          unset($str,$out, $prox, $dir, $pasos, $real);
        }
      }
      // Compara lugares próximos XY
      for($i=0; $i<2; $i++){
        $prox[$i] = $this->lugares[$lugar][$i];
        $real[$i] = $prox[$i]-$this->actual[$i];
        // Dirección de movimiento
        $dir[$i] = ($real[$i] > 0)? 1 : 0;
        // Modifica posición actual
        $this->actual[$i] += $real[$i];
        // (2000 pasos/rev)/(12 mm/rev) = 166.6667 pasos/mm
        $pasos[$i] = round(abs($real[$i])*$this->pasos[$i]);
      }
      if($this->FinRutina(0) == 0){
        // Checa si existen pausas o ejecuta
        $this->Pausas();
        $str = "sudo ../C/xy $dir[0] $dir[1] $pasos[0] $pasos[1] $vxy 2>&1";
        exec($str, $out);
        unset($str,$out, $prox, $dir, $pasos, $real);
      }
      if ($typeZ == "Lugar"){
        // Finaliza con movimiento simple Z
        $prox = $this->lugares[$lugar][2];
        $real = $prox-$this->actual[2];
        // Dirección de movimiento
        $dir = ($real > 0)? 1 : 0;
        // Modifica posición actual
        $this->actual[2] += $real;
        // (2000 pasos/rev)/(8.02 mm/rev) = 250 pasos/mm
        $pasos = round(abs($real)*$this->pasos[2]);
        if($this->FinRutina(0) == 0){
          // Checa si existen pausas o ejecuta
          $this->Pausas();
          $str = "sudo ../C/z $dir $pasos $vz 2>&1";
          exec($str, $out);
          unset($str,$out, $prox, $dir, $pasos, $real);
        }
      }
      // Finaliza con el movimiento
      $this->ActualizaMov();
    }
    // Realiza oscilaciones en lavado
    public function Lavado($osc){
      if($this->FinRutina(0) == 0){
        // Oscila alrededor de 4 mm
        $pasos = 4*$this->pasos[0];
        for($i=0; $i<$osc*2; $i++){
          // Realiza movimiento
          $dir = ($i%2 == 0)? 1 : 0;
          $str = "sudo ../C/x $dir $pasos 100 2>&1";
          exec($str, $out);
          unset($str,$out);
        }
      }
    }
    // Realiza vacío después de lavado o la toma de muestra con un tiempo de espera
    public function Espera($tiempo,$BVac){
      if($this->FinRutina(0) == 0){
        // Baja para limpieza 4 mm
        $pasos = 4*$this->pasos[2];
        // Realiza movimiento de bajada
        $str = "sudo ../C/z 1 $pasos 100 2>&1";
        exec($str, $out);
        unset($str,$out);
        //Enciende la bomba de vacío si se le indica
        if ($BVac == 1)
          $this->BVac(1);
        // Espera y sube
        sleep($tiempo);
         //Apaga bomba de vacío
        $this->BVac(0);
        $str = "sudo ../C/z 0 $pasos 100 2>&1";
        exec($str, $out);
        unset($str,$out);
      }
    }
    //Enciende o apaga la bomba de vacío
    public function BVac($estado){
        $str = "sudo ../C/vac $estado 2>&1";
        exec($str, $out);
        unset($str,$out);      
    }
    // Realiza la inserción del punto en el vidrio del Slide
    public function InsertarPunto($utoque,$Ydist){
      if($this->FinRutina(0) == 0){
        // Revisa pausas para ejecutar
        $this->Pausas();
        $this->Toque();
        // Avanza distancia en Y
        if ($utoque!=1){
          $pasos =  round($this->pasos[1]*$Ydist);
          // Revisa pausas y ejecuta
          $str = "sudo ../C/y 1 $pasos 100 2>&1";
          exec($str, $out);
          unset($str,$out);
          $this->actual[1] += $Ydist;
          $this->PinSB(1,2);
        }
        $this->ActualizaMov();

      }
    }
    // Toca el pin, sube y baja instantáneamente
    public function Toque(){
      if($this->FinRutina(0) == 0){
        // Baja 3 mm
        $pasos = 3*$this->pasos[2];
        $str = "sudo ../C/z 1 $pasos 100 2>&1";
        exec($str, $out);
        unset($str,$out);
        // Sube 5 mm para saltar gotita
        $pasos = 5*$this->pasos[2];
        $str = "sudo ../C/z 0 $pasos 100 2>&1";
        exec($str, $out);
        unset($str,$out);
        $this->actual[2] -= 2;
      }
    }
    // Sube o baja el pin
    public function PinSB($dir,$mm){
      if($this->FinRutina(0) == 0){
        // Revisa pausas y ejecuta
        $this->Pausas();
        if ($mm == "zslide")
          $mm = $this->zslide;
        $pasos = $mm*$this->pasos[2];
        // Realiza movimiento de bajada o subida
        $str = "sudo ../C/z $dir $pasos 100 2>&1";
        exec($str, $out);
        unset($str,$out);
        if ($dir==0)
          $this->actual[2] -= $mm;
        else
          $this->actual[2] += $mm;
        $this->ActualizaMov();
      }
    }
    // Establece el estado de la rutina (1-inicia / 2-finaliza) o revisa nada mas (0-checa)
    public function FinRutina($val){
      // Inicializa con sesión sin fin establecido
      session_name("IFCLab");
      session_start();
      // Revisa estado de la rutina
      if($val == 0)
        $this->fin = $_SESSION['Fin']-1;
      // Da valor de rutina iniciada (1) o finalizada (2)
      else{
        $_SESSION['Pausa'] = 0;
        $_SESSION['Fin'] = $val;
        $this->fin = $val-1;
      }
      session_write_close();
      unset($val);
      // Si fin es 1, se determinó fin desde exterior y muere la instancia
      if( $this->fin == 1 )
        exit();
      return $this->fin;
    }
    // Checa si existe alguna pausa y espera hasta que desaparece
    private function Pausas(){
      // Revisa pausas
      do{
        session_name("IFCLab");
        session_start();
        // Pone valor cero si pausa no existe
        if(!isset($_SESSION['Pausa']))
          $_SESSION['Pausa'] = 0;
        $ps = $_SESSION['Pausa'];
        session_write_close();
        usleep(500000);
      }while( $ps == 1 );
    }
    // Consigue pasos por eje y coordenadas de "lugares"
    private function DatosDB(){
      $conexion = ConectarBD();
      // Comprueba conexión para los datos
      if( $conexion == false ){
        $this->pasos = [0,0,0];
        $this->lugares = ["Origen"=>[0,0,0]];
      }
      else{
        // Pide datos de pasos de motor por eje
        mysqli_set_charset($conexion,"utf8");
        $sql = "SELECT id,valor FROM raspberry WHERE tipo != 'gpio'";
        $res = mysqli_query($conexion, $sql);
        if( $res->num_rows !=0 ) {
          // Asigna valores de base
          while ( $dato = mysqli_fetch_assoc($res) )
            $cuentas[$dato['id']] = (float) $dato['valor'];
          mysqli_free_result($res);
          // Realiza cuentas para XYZ
          $ejeBD = ["X","Y","Z"];
          for($i = 0; $i<3; $i++)
            $this->pasos[$i] = round( $cuentas['pasosRev'.$ejeBD[$i]]/$cuentas['tor'.$ejeBD[$i]] , 3);
        }
        // Pide datos de coordenadas de lugares principales
        $sql = "SELECT * FROM config";
        $res = mysqli_query($conexion, $sql);
        if( $res->num_rows !=0 ) {
          while( $dato = mysqli_fetch_assoc($res) )
            $this->lugares[$dato['nombre']] = [$dato["x"], $dato["y"], $dato["z"]];
          mysqli_free_result($res);
        }
        //Configura las variables que se utilizarán en la inserción de puntos en los Slides, Muestra y Limpieza
        $this->ReiniciaCoords(2,"Slide","Retícula");
        $this->zslide=$this->lugares["Retícula"][2]-$this->lugares["Slide"][2];
        $this->ReiniciaCoords(2,"ToqueLimpieza","Limpieza");
        $this->lugares["ToqueLimpieza"][2]=$this->lugares["Limpieza"][2];
        $this->ReiniciaCoords(2,"TomaMuestra","Muestra");
        $this->lugares["TomaMuestra"][2]=$this->lugares["Muestra"][2];
        // Manda rápidamente a sesión los datos de la posición de muestra XY para animación
        session_name("IFCLab");
        session_start();
        $_SESSION['Cambio'] = [ $this->lugares["Muestra"][0] , $this->lugares["Muestra"][1] ];
        session_write_close();
      }
    }
    //Reinicia los parámetros del lugar indicado
    public function ReiniciaCoords($i,$Lugar1,$Lugar2){
      if ($i == 0 || $i == 2)
          $this->lugares[$Lugar1][0]=$this->lugares[$Lugar2][0];
      if ($i == 1 || $i == 2)
          $this->lugares[$Lugar1][1]=$this->lugares[$Lugar2][1];
    }
    //Actualiza los datos de las coordenadas del lugar indicado
    public function ActualizaCoords($i,$distancia,$Lugar){
      $this->lugares[$Lugar][$i]+=$distancia;
    }
    //Actualiza las pausas por cambio de placa o de vidrio de limpieza
    public function ActualizaPausa($cambioPlaca,$cambioVidrio){
      // Mete valor de pausa en sesión
      session_name("IFCLab");
      session_start();
      $_SESSION['Cambio'] = [ $cambioPlaca , $cambioVidrio ];
      $_SESSION['Pausa'] = 1;
      session_write_close();
      // Deja en ciclo de pausa hasta que desactiva usuario
      $this->Pausas();
    }
    // Actualiza datos actual de sesiones a movimiento principal
    private function ActualizaMov(){
      session_name("IFCLab");
      session_start();
      $_SESSION['Actual'] = $this->actual;
      session_write_close();
    }
  }
?>
