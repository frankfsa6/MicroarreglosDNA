<link rel="stylesheet" href="css/joystick.css?v=2">
<script type="text/javascript" src="js/joystick.js?v=2" ></script>
<?php
  // Compila los archivos con gcc
  $nombre = ["o","x","xy","y","z","vac"];
  for($i = 0; $i<sizeof($nombre); $i++){
    $str = "sudo rm ../C/$nombre[$i] -f 2>&1";
    exec($str);
    $str = "sudo gcc -Wall -pthread -o ../C/$nombre[$i] ../C/$nombre[$i].c -lpigpio -lm 2>&1";
    exec($str);
  }
  // Escribe joystick de imágenes
  echo "<div class='container'><div class='row'><div class='col-6'><center>
  <table><tbody><tr>
    <td>&nbsp</td>
    <td>&nbsp</td>
    <td class='algo c' title='Arriba'><img id='z0' src='img/dir.svg'></td>
    <td>&nbsp</td>
    <td class='algo c' title='Abajo'><img id='z1' src='img/dir.svg'></td>
  </tr><tr height='30px'></tr><tr>
    <td class='vel c cc' title='Velocidad rápida'><img id='v1' src='img/v1.svg'></td>
    <td>&nbsp</td>
    <td class='algo2 c' title='Diagonal izquierda atrás'><img id='d0' src='img/dir0.svg'></td>
    <td class='algo c' title='Atrás'><img id='y0' src='img/dir0.svg'></td>
    <td class='algo2 c' title='Diagonal derecha atrás'><img id='d1' src='img/dir0.svg'></td>
  </tr><tr>
    <td class='vel u' title='Velocidad media'><img id='v2' src='img/v2.svg'></td>
    <td>&nbsp</td>
    <td class='algo c' title='Izquierda'><img id='x0' src='img/dir0.svg'></td>
    <td class='c' id='o' title='Sensar origen'><img src='img/casa.svg'></td>
    <td class='algo c' title='Derecha'><img id='x1' src='img/dir0.svg'></td>
  </tr><tr>
    <td class='vel d' title='Velocidad lenta'><img id='v3' src='img/v3.svg'></td>
    <td>&nbsp</td>
    <td class='algo2 c' title='Diagonal izquierda adelante'><img id='d2' src='img/dir0.svg'></td>
    <td class='algo c' title='Adelante'><img id='y1' src='img/dir0.svg'></td>
    <td class='algo2 c' title='Diagonal derecha adelante'><img id='d3' src='img/dir0.svg'></td>
  </tr></tbody></table></center></div>";
  // Escribe campos de texto con valores
  echo "<div class='col-6'>
    <label for='pasosx'>Pasos y distancia en eje X</label>
    <div class='input-group mb-2'>
      <input class='form-control' id='pasosx' type='text' value='0' disabled>
      <div class='input-group-prepend'><div class='input-group-text'>
        <span id='mmx'>0</span> &nbsp; mm &nbsp;( &nbsp;
        <span id='xpasosmm'></span> &nbsp; pasos / mm ) 
      </div></div>
    </div>
    <label for='pasosy'>Pasos y distancia en eje Y</label>
    <div class='input-group mb-2'>
      <input class='form-control' id='pasosy' type='text' value='0' disabled>
      <div class='input-group-prepend'><div class='input-group-text'>
        <span id='mmy'>0</span> &nbsp; mm &nbsp;( &nbsp;
        <span id='ypasosmm'></span> &nbsp; pasos / mm ) 
      </div></div>
    </div>
    <label for='pasosz'>Pasos y distancia en eje Z</label>
    <div class='input-group mb-2'>
      <input class='form-control' id='pasosz' type='text' value='0' disabled>
      <div class='input-group-prepend'><div class='input-group-text'>
        <span id='mmz'>0</span> &nbsp; mm &nbsp;( &nbsp;
        <span id='zpasosmm'></span> &nbsp; pasos / mm ) 
      </div></div>
    </div>";
    // Escribe botones de lugares
    echo "<label for='lugares'>Lugares conocidos</label></br>
    	<button type='button' class='btn btn-dark calibrar'>Calibración manual</button>
      <button type='button' class='btn btn-outline-secondary lugares'>Vacío</button>
      <button type='button' class='btn btn-outline-secondary lugares'>Lavado</button>
      <button type='button' class='btn btn-outline-secondary lugares'>Limpieza</button>
      <button type='button' class='btn btn-outline-secondary lugares'>Muestra</button>
      <button type='button' class='btn btn-outline-secondary lugares'>Retícula</button>
      <button type='button' class='btn btn-outline-secondary lugares'>Slide</button>
      <button type='button' class='btn btn-outline-secondary lugares'>Usuario</button>
	  </br></br>
   </div></div></div>";
?>
