// Variables para determinar velocidad, eventos(pingu, movjoys), flecha, pasosMM y ejes
var vel, pingus, movjoys, bot, pasosMM, ejes = ["x","y","z"];
// Función que habilita o deshabilita funcionalidad de joystick completo
function jAlgoFunciona(func){
  // Habilita todo
  if( func ){
    // Velocidad y botones de lugares
    $(".vel").on("click", jVel);
    $(".lugares").on("click", jLugares);
    $(".lugares").prop("disabled", false);
    // Ventana emergente y realiza la calibración
    $(".calibrar").on("click", popCalibra);
    $("#o").on("click", jCalibra);
    // Presionar y soltar botón de ratón en flechas
    $(".algo").on("mousedown", jBotones);
    $(".algo").on("mouseup", function(){
      $.ajax({
        type: 'POST',
        url:"php/joysMotores.php",
        data: {"rev":2}
      }).always(function(){
        espInterm("joys", 0);
      });
    });
  }
  // Deshabilita todo
  else{
    $(".vel, .lugares, .calibrar, #o, .algo").off();
    $(".lugares").prop("disabled", true);
  }
}
// Establece o quita funciones intermitentes
function espInterm(tipo, ini){
  if(tipo == "pingu"){
    // Pone pingus
    if(ini == 1){
      pingus = setInterval(function(){
        // Al llegar a 2 segundos (4 pingus), reinicia cuenta
        if( $("#pingu").children().length >= 4)
          $("#pingu").empty();
        $("#pingu").append("<img src='img/pingu.svg' width=25px'>");
      },500);
    }
    // Apaga intermitente
    else
      clearInterval(pingus);
  }
  else{
    // Pide valores de joystick
    if(ini == 1){
      movjoys = setInterval(function(){
        $.ajax({
          type: 'POST',
          url:"php/joysMotores.php",
          data: {"rev":0}
        }).done(function(datos){
          datos = datos.split(",");
          $("#mm"+datos[0]).text(datos[1]);
        });
      },100);
    }
    // Apaga intermitente
    else
      clearInterval(movjoys);
  }
}
// Función que cambia velocidad y colores asociados
function jVel(){
  // Actualiza valor de velocidad y quita colores
  vel = $(this).children().attr("id").replace("v","");
  $(".vel").removeClass("cc uu dd");
  // Asigna nuevos colores
  var color = $(this).attr("class").replace("vel ","");
  $(".algo, .algo2, #o").removeClass("c u d").addClass(color);
  $(this).addClass(color+color);
  // Mensaje en informativo
  color = $(this).attr("title");
  $("#info").html("<b>"+color+"</b> seleccionada (no aplica para sensar origen ni lugares conocidos)").show();
}
// Mueve joystick según dirección dada
function jBotones(){
  // Obtiene botón presionado
  bot = $(this).children().attr("id").split("");
  // Checa que no vaya más allá del origen
  if(bot[1] == "0" && $("#mm"+bot[0]).text() == "0" ){
    bot = false;
    $("#info").html("No se pueden mover más en dirección al origen"); 
  }  
  else{
    $("#info").html("Eje "+bot[0]+" en movimiento");
    bot = bot[0]+","+bot[1]+","+$("#mm"+bot[0]).text();
  }
  // Evita ajax en vano si no es posible mover motores
  if( bot != false ){
    // Primera llamada ajax que inicia joystick con valor en sesión
    $.ajax({
      type: 'POST',
      url:"php/joysMotores.php",
      data: {"rev":1}
    }).done(function(){
      // Si inicializa valor en sesión, comienza animación
      espInterm("joys", 1);
      // Segunda llamada ajax comienza motores
      $.ajax({
        type: 'POST',
        url:"php/joysMotores.php",
        data: {"bot":bot, "vel":vel}
      }).done(function(datos){
        // En caso de algún error al sensar, finaliza intermitente
        espInterm("movjoys", 0);
        // Coordenadas finales en ejes
        datos = datos.split(",");
        $("#info").html(datos[0]+bot[0]);
        $("#mm"+bot[0]).text(datos[1]);
      // Error segunda llamada ajax
      }).fail(function(){
        $("#error").text("Ocurrió un error conectando a motores").show();
      });
    // Error primera llamada ajax
    }).fail(function(){
      $("#error").html("Ocurrió un error conectando php").show();
    });
  }
}
// Usa botones para ir a lugares específicos
function jLugares(){  
  // Apaga eventos y genera pingus
  jAlgoFunciona(false);
  $("#info").html("Posicionando sistema en lugar solicitado &nbsp;<span id='pingu'></span>").show();
  espInterm("pingu",1);
  // Obtiene lugar y posición actual de motores en mm
  var lug = $(this).text();
  for(var i=0; i<3; i++)
    lug += ","+ $("#mm"+ejes[i]).text();
  // Llama php con datos obtenidos:"lugar,X,Y,Z"
  $.ajax({
    type: 'POST',
    url:"php/joysMotores.php",
    data: {"lug":lug}
  }).done(function(datos){
    // Recibe nuevas posiciones de motores (mm) en campos de texto
    datos = datos.split(",");
    for(i=0; i<3; i++){
      $("#pasos"+ejes[i]).val( Number(datos[i+1]*pasosMM[i]).toFixed(0) );
      $("#mm"+ejes[i]).text( datos[i+1] );
    }
    // Actualiza informativos
    $("#info").html("Ubicación del sistema: "+datos[0]).show();
  }).fail(function(){
    // Manda error
    $("#error").text("Ocurrió un error conectando php").show();
  }).always(function(){
    // Finaliza pingus y habilita todo
    jAlgoFunciona(true);
    espInterm("pingu",0);
  });
}
//Botón que inicia la calibración o lleva a origen
function jCalibra(){
  // Apaga eventos y genera pingus con mensajes
  jAlgoFunciona(false);
  $("#cerrarPopup").hide();
  // Recopila datos para enviar con casita
  if( $(this).attr("id") == "o" ){
    bot = "o";
    $("#info").html("Sensando origen &nbsp;<span id='pingu'></span>");
    // Checa si no es primera vez y pide valores
    if( $("#error").text() == "" )
      for(var i = 0; i<3; i++){
        if( $("#mm"+ejes[i]).text() == "0" )
          bot += ",0";
        else
          bot += ","+$("mm"+ejes[i]).text();
      }
    else
      $("#error").empty().hide();
  }
  // Recopila datos para enviar con casita
  else{
    $("#oo").html("Calibrando sistema &nbsp;<span id='pingu'></span>").attr("disabled",true);
    bot = "oo,0,0,0";
  }
  espInterm("pingu",1);
  // Llama php a origen
  $.ajax({
    type: 'POST',
    url:"php/joysMotores.php",
    data: {"bot":bot}
  }).done(function(datos){
    // Inicializa campos de texto
    $("#pasosx, #pasosy, #pasosz").val("0");
    $("#mmx, #mmy, #mmz").text("0");
    $("#info").html("Ubicación del sistema: Origen").show();
    // Manda detalles de sensado en origen
    $("#cargadoDeRutina, #ventanaProceso, #subeRutina, #calibrar").empty();
    $("#overlay, #popup").addClass("active");
    datos = datos.split(",");
    $("#popupjoys").html("<b>"+datos[0]+"</b></br></br>Eje X : "+datos[1]+"</br>Eje Y : "+datos[2]+"</br>Eje Z : "+datos[3]);
  }).fail(function(){
    // Manda info de error
    $("#error").text("Ocurrió un error conectando php").show();
  }).always(function(){
    // Finaliza pingus
    jAlgoFunciona(true);
    espInterm("pingu",0);
    $("#cerrarPopup").show();
  });
}
// Carga ventana emergente para calibrar
function popCalibra(){
  $("#cargadoDeRutina, #ventanaProceso, #popupjoys, #subeRutina").empty();
  $("#overlay, #popup").addClass("active");
  $("#calibrar").html("<h3>Aviso importante</h3></br>Esta función es utilizada para medir la distancia entre el origen y algún lugar en específico. Dará la medida en los tres ejes (X,Y,Z) con precisión milimétrica. Puede usar estas mediciones para especificar las distancias de los lugares específicos (pantalla de configuración).");
  $("#calibrar").append("</br></br> Para realizar la calibración manual del sistema:</br><b>1)</b> Apague los motores.</br>");
  $("#calibrar").append("<b>2)</b> Posicione manualmente los motores en el lugar deseado, tomando como <b> referencia el primer pin en el cabezal </b> usado para poner muestras.</br>");
  $("#calibrar").append("<b>3)</b> Encienda los motores. </br><b>4)</b> Presione <b>Iniciar calibración</b> y espere la obtención de las coordenadas.</br></br>");
  $("#calibrar").append("<button type='button' class='btn btn-dark btn-lg btn-block' id='oo'>Iniciar calibración</button>");
}
// Inicia con recursos al cargar página
$(document).ready( function(){
  // Pide ajax para referencia pasos por mm (únicamente una vez)
  $.ajax({
    type: 'POST',
    url:"php/joysMotores.php",
    data: {"pasos":1}
  }).done(function(datos){
    // Recibe nuevas posiciones de motores (mm) en campos de texto
    datos = datos.split(",");
    pasosMM = [ datos[0], datos[1], datos[2] ];
    for(var i=0; i<3; i++)
      $("#"+ejes[i]+"pasosmm").text(pasosMM[i]);
    // Asigna eventos que cambian velocidad/colores, botones y lugares específicos
    jAlgoFunciona(true);
    vel = 1;
    $("#calibrar").on("click","#oo", jCalibra);
    $("#info, #botones, #error").empty().hide();
    $("#info").html("<b>Velocidad rápida</b> seleccionada (no aplica para sensar origen ni lugares conocidos)").show();
    $("#error").html("Se recomienda presionar <img src='img/casa.svg' alt='Origen' width=25px'> para inicializar correctamente los pasos").show();  
  }).fail(function(){
    // Evita que se ejecuten funciones si no hay valores
    jAlgoFunciona(false);
    pasosMM = [0,0,0];
    $("#xpasosmm, #ypasosmm, #zpasosmm").text(0);
    $("#info, #botones").empty().hide();
    $("#error").html("No se pudieron obtener los valores de medición para el joystick").show();  
  });
});
