// Variable que guarda la posicion en la que se encuentra
var actual = null ;
// Se crea un array que controla el movimiento de las páginas
var pages = ["pines","reticula","slide","lavado"];
// Variable que controla si se carga una rutina o se inicia una nueva
var tempNC = null;
// Variable que toma tiempo para refrescar posición obtenida (1s=1000)
var interm = 1000;
// Variable que permite modificar en las distintas pestañas una vez guardado el programa
var pageKey = false;
// Espacios en canvas [largo, ancho, multipix, divX, divY, cuentaX, cuentaY, placaTerminada, placasTotales]
var canTam = [24, 16, 30, 0, 0, 0, 1, 0, 0];
// Tamaño de la placa de muestra y también entrada-salida
var muestraTam = [0, 0, 0, 0, 0];
// Dibuja el canvas limpio y botones para animación de progreso
function dibCanv(){
	//El div a modificar es ventanaProceso
	$("#popup").css("width","85%");
	$("#overlay").addClass("active");
	$("#popup").addClass("active");
	$("#cerrarPopup").hide();
	//Borra el contenido de los otros DIVS dentro del popup
	$("#cargadoDeRutina").empty();
	$("#subeRutina").empty();
	$("#popupjoys").empty();
	$("#calibrar").empty();
	//Realiza el contenedor del canvas
	$("#ventanaProceso").html("<h3> "+$("#rutAct").text()+"</h3> </br>");
	$("#ventanaProceso").append("<div class='alert alert-info' id='infoProceso'> </div>");
	$("#infoProceso").hide();
	$("#ventanaProceso").append("<div class='canvas-container'><canvas id='canvas1' width="+canTam[0]*canTam[2]+" height="+canTam[1]*canTam[2]+"> </canvas> </div>");
	// Datos de placa, botones de pausa y paro
	$("#ventanaProceso").append("<b>Placas de muestra faltantes: </b><b id='cuentaT'></b></br><b>Placas terminadas: </b><b id='cuentaM'></b></p><p id='posiciones'></p></br>").show();
	$("#ventanaProceso").append("<table style='width:37%' id='tablaBotonesProceso' align='right'><tr>").show();
	$("#tablaBotonesProceso").append("<tr><th><button type='button' class='btn btn-primary btn-lg btn-block' id='pausaRutina'><u>P</u>ausa</button></th></tr>");
	$("#tablaBotonesProceso").append("<tr><th><button type='button' class='btn btn-outline-light btn-lg btn-block' disabled>boton</button></tr>");
	$("#tablaBotonesProceso").append("<tr><th><button type='button' class='btn btn-success btn-lg btn-block' id='continuaRutina' disabled><u>R</u>eanudar proceso</button></th></tr>");
	$("#tablaBotonesProceso").append("<tr><th><button type='button' class='btn btn-outline-light btn-lg btn-block' disabled>boton</button></tr>");
	$("#tablaBotonesProceso").append("<tr><th><button type='button' class='btn btn-danger btn-lg btn-block' id='paroTotal'>Paro <u>t</u>otal</button></th></tr>");
	$("#ventanaProceso").append("</tr></table> </br>");
	$("#navs").hide();
	// Crea líneas que dividen la placa muestra
	linCanv();
}
// Colorea un área de las muestras en lienzo
function colCanv(){
	// Checa si finaliza muestra
	if( canTam[5]*canTam[6] == canTam[3]*canTam[4] ){
		// Reinicia secciones y limpia lienzo
		canTam[5] = 1;
		canTam[6] = 1;
		linCanv();
	}
	// Revisa que haya acabado la columna "X derecha" de muestras
	else if (canTam[5]==canTam[3]) {
		canTam[6]++;
		canTam[5] = 1;
	}
	// Actualiza valor cuando llega a la penúltima sección de la muestra
	else if( canTam[6]==canTam[4] && canTam[5]==canTam[3]-1 ){
		canTam[5]++;
		canTam[7]++;
	}
	// Siempre aumenta en columna "X derecha" los movimientos
	else
		canTam[5]++;
	// Contexto para inciar el lienzo
	var anima = document.getElementById("canvas1").getContext("2d");
	anima.fillStyle = "#ffd043";
	// Colorea los círculos en lienzo
	for(i=1; i<=canTam[0]/canTam[3]; i++){
		var offx = canTam[0]/canTam[3]*(canTam[5]-1)*canTam[2];
		for(j=1; j<=canTam[1]/canTam[4]; j++){
			var offy = canTam[1]/canTam[4]*(canTam[6]-1)*canTam[2];
			anima.beginPath();
			anima.arc(i*canTam[2]+offx-canTam[2]/2, j*canTam[2]+offy-canTam[2]/2, 10, 0, 2*Math.PI);
			anima.fill();
		}
	}
}
// Dibuja las líneas a dividir el lienzo y sus círculos iniciales
function linCanv(){
	// Encuentra los pines puestos, sus divisores y los bloques contados
	var cadPin = $("#pags table tbody").children("tr").first().children("td").last().text().split(" ");
	canTam[3] = canTam[0]/cadPin[0];
	canTam[4] = canTam[1]/cadPin[1];
	// Encuentra el total de placas, en el resumen en la página
	cadPin = $("#pags table tbody").children("tr").first().next().children("td").last().text().split(" ");
	canTam[8] = cadPin[ cadPin.length-1 ]-canTam[7];
	// Valores iniciales de texto
	$("#cuentaT").text(canTam[8]);
	$("#cuentaM").text(canTam[7]);
	// Obtiene contexto para iniciar el lienzo
	var anima = document.getElementById("canvas1").getContext("2d");
	anima.clearRect(0, 0, document.getElementById("canvas1").width, document.getElementById("canvas1").height);
	anima.lineWidth = 2;
	anima.strokeStyle = "#a6a6a6";
	// Dibuja las líneas primordiales X
	for(var i=1; i<=canTam[3]; i++){
		anima.beginPath();
		anima.moveTo(i*canTam[0]*canTam[2]/canTam[3], 0);
		anima.lineTo(i*canTam[0]*canTam[2]/canTam[3], canTam[1]*canTam[2]);
		anima.stroke();
	}
	// Dibuja las líneas primordiales Y
	for(i=1; i<=canTam[4]; i++){
		anima.beginPath();
		anima.moveTo(0, i*canTam[1]*canTam[2]/canTam[4]);
		anima.lineTo(canTam[0]*canTam[2], i*canTam[1]*canTam[2]/canTam[4]);
		anima.stroke();
	}
	// Dibuja los círculos en lienzo
	for(i=1; i<=canTam[0]; i++)
		for(var j=1; j<=canTam[1]; j++){
			anima.beginPath();
			anima.arc (i*canTam[2]-canTam[2]/2, j*canTam[2]-canTam[2]/2, 10, 0, 2*Math.PI);
			anima.stroke();
		}
}
// Crea los botones
function creaBotones (pags) {
		if(pags != 'login' && pags != 'joystick')
		{
			$("#botones").html("<table style='width:100%' id='tablaBotonesRutina'><tr>").show();
			if(pags == 'pines')
			{
				$("#tablaBotonesRutina").append("<th><button type='button' class='btn btn-outline-light btn-lg btn-block' disabled>boton</button></th>");
				$("#tablaBotonesRutina").append("<th><button type='button' class='btn btn-outline-light btn-lg btn-block' disabled>boton</button></th>");
				$("#tablaBotonesRutina").append("<th><button type='button' class='btn btn-primary btn-lg btn-block' id='Siguiente'><u>S</u>iguiente</button></th>");
			}
			else
			{
				if (pags == 'lavado' )
				{
					$("#tablaBotonesRutina").append("<th><button type='button' class='btn btn-primary btn-lg btn-block' id='Anterior'><u>A</u>nterior</button></th>");
					$("#tablaBotonesRutina").append("<th><button type='button' class='btn btn-outline-light btn-lg btn-block' disabled>boton</button></th>");
					$("#tablaBotonesRutina").append("<th><button type='button' class='btn btn-success btn-lg btn-block' id='retornoPP'><u>R</u>utina lista</button></th>");
				}
				else
				{
					$("#tablaBotonesRutina").append("<th><button type='button' class='btn btn-primary btn-lg btn-block' id='Anterior'><u>A</u>nterior</button></th>");
					$("#tablaBotonesRutina").append("<th><button type='button' class='btn btn-outline-light btn-lg btn-block' disabled>boton</button></th>");
					$("#tablaBotonesRutina").append("<th><button type='button' class='btn btn-primary btn-lg btn-block' id='Siguiente'><u>S</u>iguiente</button></th>");
				}
			}
			$("#botones").append("</tr></table> </br>");
		}
}
// Carga página principal.php: "v" indica si info será visible, info mostrará el mensaje
function cargaPrincipal(){
	// Comienza a crear menú inicial
	$.post("php/principal.php", function(datos){
		$("#info").empty().hide();
		$("#error").empty().hide();
		$("#botones").empty().show();
		$("#pags").html(datos);
		//Crea los botones de guardado y nueva rutina
		$("#botones").html("<table style='width:100%' id='tablaBotonesRutina'><tbody><tr></tr>");
		$("#tablaBotonesRutina").append("<td><button type='button' class='btn btn-outline-danger btn-lg btn-block' id='nuevaRutina'>N<u>u</u>eva rutina</button><span> </span></td>");
		$("#tablaBotonesRutina").append("<td> </td>");
		$("#tablaBotonesRutina").append("<td><button type='button' class='btn btn-outline-warning btn-lg btn-block' id='cargaRutina'><u>C</u>argar rutina</button><span> </span></td>");
		$("#tablaBotonesRutina").append("<td> </td>");
		//Verifica si está definida la sesión y muestra el botón de guardar
		$.post("php/LSArch.php",{checkSesion:true}, function(datos){
			if(datos == '1'){
				//Cambia el contenido del botón dependiendo si la rutina ya fue guardada
				$.post("php/LSArch.php",{temporal:true}, function(resp){
					if(resp == '0') //la rutina ya está guardada
						$("#tablaBotonesRutina").append("<td><button type='button' class='btn btn-outline-primary btn-lg btn-block' id='guardaRutina' >R<u>e</u>nombrar rutina</button><span> </span></td>");
					else if(resp == '1')
						$("#tablaBotonesRutina").append("<td><button type='button' class='btn btn-outline-primary btn-lg btn-block' id='guardaRutina' ><u>G</u>uardar rutina</button><span> </span></td>");
					$.post("php/LSArch.php",{rutinaIniciada:true}, function(datos){
						if(datos == '0'){
							pageKey = true;
							$("#tablaBotonesRutina").append("<td> </td>");
							$("#tablaBotonesRutina").append("<td><button type='button' class='btn btn-success btn-lg btn-block' id='inicioProceso'><u>I</u>niciar proceso</button></td></tr>");
							if(!$("#codigoG").length)
								$("#botonesfooter").append("<button type='button' class='btn btn-md btn-light' id='codigoG'>Có<u>d</u>igo G &nbsp;&nbsp;<img src='img/document.svg' width='20px'/></button>");
						}
						else if(datos == '1'){
							pageKey = false;
							//$("li").removeClass("active");
						}
					});
				});
			}
			else {
					pageKey = false;
					$("li").removeClass("active");
			}
		});

		$("#botones").append("</tbody></table> </br>");
	}).fail(function(datos){
		$("#info, #pags, #botones").empty();
		$("#info").hide();
		$("#error").text("No se pudo iniciar el servicio").show();
		console.log("Error ajax por petición de página principal:"+JSON.stringify(datos));
	});
	// Verifica si existe alguna rutina actual
	//revisaRut(0);
}
// Crea la nueva rutina y manda a llamar a pines.php
function cargaNuevaRutina(){
	actual = 'pines';
	pageKey = false;
	//la peticion ajax envia un valor que activa una funcion en pines.php y crea un nuevo ID
	$.ajax({
		type:'POST',
		url:'php/pines.php',
		data:{
			creaID : true
		},
			success: function(){
				pags = 'pines';
				$("li").removeClass("active");
				//Se busca la clase que esta activa en la NavBar para que cambie el resaltado dependiendo de que boton se presiona
				$("li").find("a#"+pags).parent().addClass("active");
				$.post("php/"+pags+".php", function(datos){
					var indice = buscaIndice(pags);
					$("#info").text("Paso: "+indice+" de 4").show();
					$("#error").empty().hide();
					$("#pags").html(datos);
					//Botones de cada página
					creaBotones(pags);
			}).fail(function(datos){
				$("#info, #pags, #botones").empty();
				$("#info").hide();
				$("#error").text("No se pudo iniciar el servicio").show();
				console.log("Error ajax por petición de página "+pags+":"+JSON.stringify(datos));
			});
		}
	});
}
// Verifica pestaña de ubicación
function buscaIndice(pags){
	var i = 0, indice = -1;
	for(i=0; i < pages.length; i++)
	{
		if(pages[i]==pags)
			indice=i;
	}
	return ++indice;
}
// (1,0): pone pausa, (0,0):quita pausa, (1,1):paro total
function pausaTodo(val, tipo){
	$.ajax({
		type: 'POST',
		url:"php/pausa.php",
		data: {"pausa":val,"tipo":tipo}
	}).done(function(datos){
		console.log(datos);
	}).fail(function(datos){
		console.log("Error en javascript para generar o quitar pausa:"+JSON.stringify(datos));
	});
}
// Checa si hay rutina actual o pide movimiento actual
function revisaRut(val){
	// Verifica "0" si hay rutina corriendo o "1" posición actual
	$.ajax({
		type: 'POST',
		url:"php/pausa.php",
		data: {"consul":val}
	}).done(function(datos){
		// Checa si existe alguna rutina principal corriendo
		if(val == 0){
			// Si existe rutina actual, crea intermitente
			if(datos == "1"){
				dibCanv();
				rep = setInterval(function(){
					revisaRut(1);
				},interm);
				console.log("Rutina en proceso");
			}
			else
				console.log("Sin proceso actual");
		}
		// Actualiza animación en consola con base en la posición dada
		else{
			datos = datos.split(",");
			// Si no hay datos, manda mensajito
			if(datos.length != 5)
				$("#posiciones").text("Obteniendo coordenadas");
			else{
				// Imprime posiciones en pantalla
				$("#posiciones").text("Posición XYZ ( "+datos[0]+" mm, "+datos[1]+" mm, "+datos[2]+" mm )" );
				// Genera pausa cuando cambia muestra o vidrio
				if( datos[3]!="0" || datos[4]!="0" ){
					// Pausa para cambio de muestra
					if( datos[4]=="0" ){
						$("#pausaRutina").removeAttr("disabled").trigger("click");
						$("#infoProceso").html("Se debe cambiar la placa de <b>muestras</b>. Al finalizar, presione <b>Reanudar proceso</b> para retomar la rutina").show();
						linCanv();
					}
					// Pausa para cambio de vidrio y muestra
					else if( datos[3]=="1" && datos[4]=="1" ){
						$("#pausaRutina").removeAttr("disabled").trigger("click");
						$("#infoProceso").html("Se debe cambiar la placa de <b>muestras</b> y el vidrio de <b>limpieza</b>. Al finalizar, presione <b>Reanudar proceso</b> para retomar la rutina").show();
						linCanv();
					}
					// Obtiene posiciones de placa muestra la primera vez, considerando tamaño X:148mm, Y:105mm
					else{
						$("#posiciones").text("Obteniendo coordenadas");
						if(muestraTam[0] == 0 && muestraTam[1] == 0)
							muestraTam = [ Number(datos[3]), Number(datos[3])+148, Number(datos[4]), Number(datos[4])+105, 0 ];
					}
				}
				// Únicamente colorea lienzo cuando llega a muestra
				if( Number(datos[0])>=muestraTam[0] && Number(datos[0])<=muestraTam[1] && Number(datos[1])>=muestraTam[2] && Number(datos[1])<=muestraTam[3] ){
					// Colorea una vez nada más
					if( muestraTam[4]==0 )
						colCanv();
					muestraTam[4] = 1;
				}
				else
					muestraTam[4] = 0;
			}
		}
	}).fail(function(datos){
		console.log("Error en javascript al revisar rutina: "+JSON.stringify(datos));
	});
}
// Función para activar o desactivar pantalla completa
function pantComp(){
	// Activa o desactiva
	if ( !document.fullscreenElement )
    document.documentElement.requestFullscreen();
	else
    document.exitFullscreen();
}
// Maneja teclas rápidas para eventos del navegador cuando no hay campo de texto
function tecRap(){
	if( !($(":text").length > 0 && $("#popup").attr("class") == "active") && $(":password").length <= 0 ){
		switch(event.keyCode){
			// L: cambia ventana completa
			case 76:
				$("#pantcomp").trigger("click");
				break;
			// M: abre documentación
			case 77:
				$("#docref").trigger("click");
				break;
			// O: abre créditos
			case 79:
				if( $("#creds").length > 0 &&  $("#popup").attr("class") != "active" )
					$("#creds").trigger("click");
				break;
			// D: genera el codigo G
			case 68:
				if( $("#codigoG").length > 0 &&  $("#popup").attr("class") != "active" )
				$("#codigoG").trigger("click");
				break;
			// U: nueva rutina
			case 85:
				if( $("#nuevaRutina").length > 0 &&  $("#popup").attr("class") != "active" )
					$("#nuevaRutina").trigger("click");
				break;
			// C: carga rutina
			case 67:
				if( $("#cargaRutina").length > 0 &&  $("#popup").attr("class") != "active" )
					$("#cargaRutina").trigger("click");
				break;
			// E, G: renombra o guarda rutina
			case 69:
			case 71:
				if( $("#guardaRutina").length > 0 &&  $("#popup").attr("class") != "active" )
					$("#guardaRutina").trigger("click");
				break;
			// S: botón de siguiente o sí al paro total
			case 83:
				if( $("#Siguiente").length > 0  &&  $("#popup").attr("class") != "active" )
					$("#Siguiente").trigger("click");
				else if ( $("#pTsi").length > 0 )
					$("#pTsi").trigger("click");
				break;
			// N: no en paro total
			case 78:
				if( $("#pTno").length > 0 )
					$("#pTno").trigger("click");
				break;
			// A: botón de anterior
			case 65:
				if( $("#Anterior").length > 0 &&  $("#popup").attr("class") != "active" )
					$("#Anterior").trigger("click");
				break;
			// R: rutina lista o reanudar proceso en pausa
			case 82:
				if( $("#retornoPP").length > 0  &&  $("#popup").attr("class") != "active" )
					$("#retornoPP").trigger("click");
				else if ( $("#continuaRutina").length > 0 )
					$("#continuaRutina").trigger("click");
				break;
			// I: iniciar proceso
			case 73:
				if( $("#inicioProceso").length > 0 &&  $("#popup").attr("class") != "active" )
					$("#inicioProceso").trigger("click");
				break;
			// P: pausa proceso o recarga página
			case 80:
				if( $("#pausaRutina").length > 0 )
					$("#pausaRutina").trigger("click");
				else if( $("#recPag").length > 0 )
					$("#recPag").trigger("click");
				break;
			// T: paro total
			case 84:
				if( $("#paroTotal").length > 0 )
					$("#paroTotal").trigger("click");
				break;
			// X: cierra ventanas de popup
			case 88:
				if( $("#cerrarPopup").length > 0 )
					$("#cerrarPopup").trigger("click");
				break;
		}
	}
}
// Activado cada vez que se presiona la barra de navegación
function barraNav(){
	var pags = $(this).attr("id");
	// Mientras se presione pestaña que no sea rutina
	if (pags != "principal" && pags != "logo" && ( pags == actual || pags == "joystick" || pags == "login" || pageKey) ){
		//Comprueba que la clase de joystick sea verdadera para eliminar la clase active
		$("#joystick").parent().removeClass("active");
		$("#login").parent().removeClass("active");
		//Remueve los atributos de active cuando se puede desplazar en cualquier pestaña
		if(pageKey)
			$("li").removeClass("active");
		$(this).parent().addClass("active");
		// Solicita página respectiva y escribe datos recibidos
		setTimeout(function(){
			$.post("php/"+pags+".php", function(datos){
				var indice = buscaIndice(pags);
				$("#info").text("Paso: "+indice+" de 4").show();
				$("#error").empty().hide();
				$("#pags").html(datos);
			//Botones de cada página
			creaBotones(pags);
			setTimeout(function(){
				if(actual == "reticula"){
					$(".update-db-submit").trigger("click");
				}
			},50);
		}).fail(function(datos){
				$("#info, #pags, #botones").empty()
				$("#info").hide();
				$("#error").text("No se completó la petición de página").show();
				console.log("Error ajax por petición de página "+pags+":"+JSON.stringify(datos));
			});
		},50);
	}
	// Recarga página del índice
	else{
		//Remueve el atributo de active del joystick o config
		var joyconf = $("ul").find("li.nav-item.active").children().attr("id");
		if(joyconf == "joystick" || joyconf == "login")
			$("li").removeClass("active");
		if(pags == "principal" || pags == "logo")
			cargaPrincipal();
	}
}
// Inicia documento y verifica base de datos
$(document).ready( function(){
	// Oculta secciones y checa si existe la base de datos para funcionar todo
	$("#credsTXT, #error").hide();
	$("#info").text("Cargando base de datos, espere por favor").show();
	$.ajax({
		type: 'POST',
		url:'php/bd.php',
		data: {'inicia':2}
	}).done(function(existe){
		// Carga si toda la base está bien
		if( existe ){
			// Botones de créditos y link a pdf de documentación
			$(document).on("keydown", tecRap);
			$("#pantcomp").on("click", pantComp);
			$("#credsTXT").hide();
			$("#creds").on("click", function(){ $("#credsTXT").toggle("slow") });
			$("#docref").on("click", function(){ window.open("Manual de usuario.pdf")} );
			// Carga página, barra de navegación y eventos delegados (no pueden ir con funciones externas)
			cargaPrincipal();
			$("a").on("click", barraNav);		
			// Movimiento entre páginas siguiente
			$("#botones").on("click","#Siguiente",function() {
				var actualPage = $("ul").find("li.nav-item.active").children().attr("id")
				var nextPage = $.inArray(actualPage, pages ) + 1 ;
				pags = pages[nextPage];
				actual = pags;
				//Trigger del boton que se manda a llamar para subir a la base de datos
				$(".update-db-submit").trigger("click");
				$("li").removeClass("active");
				//Se realiza la actualizacion de la base de datos
				//Es importante que guardar las variables en sessiones para poder subirlas a BD
				$("li").removeClass("active");
				$("li").find("a#"+pages[nextPage]).parent().addClass("active");
				setTimeout(function(){
					$.post("php/"+pags+".php", function(datos){
						var indice = buscaIndice(pags);
						$("#info").text("Paso: "+indice+" de 4").show();
						$("#error").empty().hide();
						$("#pags").html(datos);
					//Botones de cada página
					creaBotones(pags);
					setTimeout(function(){
						if(actual == "reticula"){
							$(".update-db-submit").trigger("click");
						}
					},100);
				}).fail(function(datos){
						$("#info, #pags, #botones").empty()
						$("#info").hide();
						$("#error").text("No se completó la petición de página").show();
						console.log("Error ajax por petición de página "+pags+":"+JSON.stringify(datos));
					});
				},100);
			});
			// Movimiento entre páginas anterior
			$("#botones").on("click","#Anterior",function() {
				var actualPage = $("ul").find("li.nav-item.active").children().attr("id")
				var nextPage = $.inArray(actualPage, pages ) - 1 ;
				pags = pages[nextPage];
				actual = pags;
				$(".update-db-submit").trigger("click");
				$("li").removeClass("active");
				$("li").find("a#"+pages[nextPage]).parent().addClass("active");
				setTimeout(function(){
					$.post("php/"+pags+".php", function(datos){
						var indice = buscaIndice(pags);
						$("#info").text("Paso: "+indice+" de 4").show();
						$("#error").empty().hide();
						$("#pags").html(datos);
					//Botones de cada página
					creaBotones(pags);
					setTimeout(function(){
						if(actual == "reticula"){
							$(".update-db-submit").trigger("click");
						}
					},50);
				}).fail(function(datos){
						$("#info, #pags, #botones").empty()
						$("#info").hide();
						$("#error").text("No se completó la petición de página").show();
						console.log("Error ajax por petición de página "+pags+":"+JSON.stringify(datos));
					});
				},50);
			});
			// LLeva a la pestaña de pines y crea el ID, manda un popup preguntando si se desea continuar sin guardar
			$("#botones").on("click","#nuevaRutina",function() {
				$.post("php/LSArch.php",{temporal:true}, function(datos){
					//Contiene los datos dados por el usuario
					var accion = datos;
					if(accion == "0")
						cargaNuevaRutina();
					else{
						if (accion == "1"){
							tempNC = "nuevo";
							//Se abre el popup que preguntará al usuario si quiere continuar
							//si continua, se borra todos los datos en la base
							$("#overlay").addClass("active");
							$("#popup").addClass("active");
							$("#cargadoDeRutina").empty();
							$("#ventanaProceso").empty();
							$("#popupjoys").empty();
							$("#calibrar").empty();
							$("#subeRutina").html("<h3>Aviso importante</h3> </br> <div class='alert alert-danger' role='alert'> Se eliminarán los datos actuales, ¿Desea continuar?</div>");
							$("#subeRutina").append("<center><table style='width:60%' id='botonesBorrarTemporal'>");
							$("#botonesBorrarTemporal").append("<th><button type='button' class='btn btn-danger btn-lg btn-block' id='borraTemp'>Continuar sin guardar</button></th>");
							$("#botonesBorrarTemporal").append("<th><button type='button' class='btn btn-info btn-lg btn-block' id='guardaTemp'>Guardar la rutina</button></th>");
							$("#subeRutina").append("</table><center>");
						}
						else
							cargaPrincipal();
							//$("#error").text("No se pudo iniciar el servicio").show();
					}
				});
			});
			// Popup de guardado de páginas
			$("#botones").on("click","#guardaRutina",function() {
				//Se agrega la clase active para que se pueda mostrar en pantalla
				$("#overlay").addClass("active");
				$("#popup").addClass("active");
				$("#cargadoDeRutina").empty();
				$("#ventanaProceso").empty();
				$("#popupjoys").empty();
				$("#calibrar").empty();
				$("#subeRutina").html("</br><h5> Nombre de la nueva rutina</h5>");
				$("#subeRutina").append("<div role='alert' id='errorSubeRutina'></br></br></div>");
				$("#subeRutina").append("<div class='input-group'>");
				$("#subeRutina").append("<input type='text' class='form-control' id='nombreDB'>");
				$("#subeRutina").append("</br><button type='button' class='btn btn-info' id='enviarNombreDB'>Enviar</button>");
				$("#subeRutina").append("</div>");
			});
			// El botón de enviar cierra el popup y manda a llamar un archivo para que guarde la base de datos
			$("#overlay").on("click","#enviarNombreDB",function(e) {
				e.preventDefault();
				if( $("#nombreDB").val() == '')
				{
					//alert($("#nombreDB").val());
					$("#errorSubeRutina").addClass('alert alert-danger');
					$("#errorSubeRutina").html("El nombre de la rutina debe contener al menos un caracter válido").removeAttr("hidden");
				}
				else{
					$("#overlay").removeClass("active");
					$("#popup").removeClass("active");
					var position = $("#info").parent().offset().top;
					$("HTML, BODY").animate({ scrollTop: position }, 500);
					//Verifica si esta definido el campo de lavado, si no, se manda una alerta al usuario
					$.ajax({
						type:'POST',
						url:'php/LSArch.php',
						data:{confirmLavado:true},
						success: function(datos){
							if(datos == '0'){
								$.ajax({
									type:'POST',
									url:'php/subeRutina.php',
									data:{
										rutina : $("#nombreDB").val(),
										re : "1"
									},
									success: function(data){
										accion = String(data);
										if(accion == '0'){
											//$("#error").html("El nombre de la rutina ya existe, por favor elija otro nombre").show();
											setTimeout(function(){
												$("#overlay").addClass("active");
												$("#popup").addClass("active");
												$("#cargadoDeRutina").empty();
												$("#ventanaProceso").empty();
												$("#popupjoys").empty();
												$("#calibrar").empty();
												$("#subeRutina").html("</br> </br> <div class='alert alert-danger' role='alert'> El nombre de la rutina ya existe ¿Desea sobreescribirla? </div>");
												$("#subeRutina").append("<center><table style='width:60%' id='reescribirRutina'>");
												$("#reescribirRutina").append("<th></br><button type='button' class='btn btn-danger btn-lg btn-block' id='reNo'>No</button></th>");
												$("#reescribirRutina").append("<th><button type='button' class='btn btn-outline-light btn-lg btn-block' disabled>boton</button></th>");
												$("#reescribirRutina").append("<th></br><button type='button' class='btn btn-info btn-lg btn-block' id='reSi'>Sí</button></th>");
												$("#subeRutina").append("</table> </br><center>");
											},500);
										}
										else{
											if(accion == '1'){
												$("#error").html("Existió un problema con al intentar conectar con la base de datos");
											}
											else{
												if(accion == '2'){
													$("#info").html("La rutina fue guardada con éxito").show();
													$("#rutinaGuardadaTexto").html("SÍ");
													$("#guardaRutina").html("R<u>e</u>nombrar rutina");
													$("h4").text( "Rutina actual: "+$("#nombreDB").val() );
													$("#error").empty().hide();
													setTimeout(function(){
														$("#info").empty().hide();
													},1000);
												}
											}
										}
									}
								});
							}
							else{
								//Se indica al usuario que no se han completado todos los datos
								$("#error").html("Para guardar la rutina es necesario definir todos los campos").show();
							}
						}
					});
				}
			});
			// Carga los nombres de la base de datos
			$("#botones").on("click","#cargaRutina",function() {
				//Se agrega la clase avtive para que se pueda mostrar en pantalla
				$("#overlay").addClass("active");
				$("#popup").addClass("active");
				$("#subeRutina").empty();
				$("#ventanaProceso").empty();
				$("#popupjoys").empty();
				$("#calibrar").empty();
				$.post("php/cargaRutina.php", function(datos){
					$("#cargadoDeRutina").html(datos);
				});
			});
			// Selecciona la base de datos de acuerdo a un boton y recarga con un nuevo id
			$("#cargadoDeRutina").on("click","button",function(e) {
				//Se borra la clase active para quitar el popup
				e.preventDefault();
				$("#overlay").removeClass("active");
				$("#popup").removeClass("active");
				//Genera una animación para cuando se cierre el popup
				var position = $("#info").parent().offset().top;
				$("HTML, BODY").animate({ scrollTop: position }, 500);
				//Se debe generar un explode para quitar el carga
				//-----------Importante------------
				//Se hace en el archivo de cargaRutina.php
				$.ajax({
					type:'POST',
					url:'php/cargaRutina.php',
					data:{
						rutinaCarga : this.id,
					},
					success: function(data){
						//Recarga la pagina para actualizar con el nuevo ID
						if( data == "borrar")
						{
							setTimeout(function(){
								$("#overlay").addClass("active");
								$("#popup").addClass("active");
								$("#cargadoDeRutina").html("<h3>Advertencia: </h3> <strong>Está a punto de borrar una rutina, ¿Desea continuar?</strong>");
								$("#cargadoDeRutina").append("<center><table style='width:60%' id='botonesBorraRutina'>");
								$("#botonesBorraRutina").append("<th></br><button type='button' class='btn btn-danger btn-lg btn-block' id='cacelarRutina'>Cancelar</button></th>");
								$("#botonesBorraRutina").append("<th></br><button type='button' class='btn btn-info btn-lg btn-block' id='borrarRutina'>Continuar</button></th>");
								$("#cargadoDeRutina").append("</table> </br><center>");
							},500);
							actual = '';
						}
						else{
							if( data == "carga"){
								$.post("php/LSArch.php",{temporal:true}, function(datos){
									//Contiene los datos de temporal
									var accion = datos;
									if(accion == "0"){
										$.ajax({
											type:'POST',
											url:'php/cargaRutina.php',
											data:{
												cargaok : true,
											},
											success: function(data){
												cargaPrincipal();
												}
											});
									}
									else{
										if (accion == "1"){
											tempNC = "carga";
											//Se abre el popup que preguntará al usuario si quiere continuar
											//si continua, se borra todos los datos en la base
											$("#overlay").addClass("active");
											$("#popup").addClass("active");
											$("#cargadoDeRutina").empty();
											$("#ventanaProceso").empty();
											$("#popupjoys").empty();
											$("#calibrar").empty();
											$("#subeRutina").html("<h3>Aviso importante</h3> </br> <div class='alert alert-danger' role='alert'> Se eliminarán los datos actuales, ¿Desea continuar? </div>");
											$("#subeRutina").append("<center><table style='width:60%' id='botonesBorrarTemporal'>");
											$("#botonesBorrarTemporal").append("<th><button type='button' class='btn btn-danger btn-lg btn-block' id='borraTemp'>Descartar y continuar</button></th>");
											$("#botonesBorrarTemporal").append("<th><button type='button' class='btn btn-info btn-lg btn-block' id='guardaTemp'>Guardar la rutina actual</button></th>");
											$("#subeRutina").append("</table><center>");
										}
										else
											$("#error").text("No se pudo iniciar el servicio").show();
									}
								});
							}
							else {
								//recarga la ventana principal en caso de haber borrado
								cargaPrincipal();
								//pageKey = false;
							}
						}
					}
				});
			});
		// Botones varios de los popup emergentes
			$("#subeRutina").on("click","button", function(){
				if($(this).attr("id") != 'enviarNombreDB'){
					$("#overlay").removeClass("active");
					$("#popup").removeClass("active");
					if($(this).attr("id") == "borraTemp"){
						$.post("php/LSArch.php",{borraTemp:true},function(datos){
							var accion = datos;
							if(accion == "0"){
								if(tempNC == "nuevo")
									cargaNuevaRutina();
								else{
									$.ajax({
										type:'POST',
										url:'php/cargaRutina.php',
										data:{
											cargaok : true
										},
										success: function(){
											cargaPrincipal();
											}
										});
									}
							}
							else
								$("#error").text("Hubo un error al conectar con la base de datos").show();
						});
					}
					else{
						if($(this).attr("id") == "guardaTemp" || $(this).attr("id") == "reNo"){
							setTimeout(function(){
								$('#guardaRutina').eq(0).click()
							},500);
						}
						else{
							if($(this).attr("id") == "reSi"){
								$.ajax({
									type:'POST',
									url:'php/subeRutina.php',
									data:{
										rutina : " ",
										re : "2"
									},
									success: function(data){
										$("#info").html("La rutina fue guardada con éxito").show();
										$("#rutinaGuardadaTexto").html("SÍ");
										$("#guardaRutina").html("R<u>e</u>nombrar rutina");
										$("#error").empty().hide();
										setTimeout(function(){
											$("#info").empty().hide();
										},1000);
									}
								});
							}
						}
					}
				}
			});
			// Cerrar popup
			$("#overlay").on("click","#cerrarPopup",function(e) {
				e.preventDefault();
				$("#overlay").removeClass("active");
				$("#popup").removeClass("active");
				$("#popup").css("width","600px");
			});
			// Recarga la pagina para llevarlo a la pagina principal
			$("#botones").on("click","#retornoPP",function() {
				$(".update-db-submit").trigger("click");
				actual = 'lavado';
				$.post("php/LSArch.php",{actualizaRutina:true});
				cargaPrincipal();
			});
			// Abre popup para iniciar proceso de rutina principal
			$("#botones").on("click","#inicioProceso", function(){
				//Se creará una ventana emergente que tendrá las imagenes del proceso
				dibCanv();
				$("#cerrarPopup").remove();
				// Inicia el proceso completo
				$.ajax({
					type: 'POST',
					url:"php/RutinaC.php",
					timeout: 0
				}).done(function(datos){
					// Actualiza últimos valores de animación
					if (datos == "Fin Rutina 2")
						$("#infoProceso").html("Ejecución finalizada por usuario.").show();
					else{
						$("#infoProceso").html("Ejecución finalizada con éxito.").show();
						// Actualiza últimos valores de animación												
						if (($("#cuentaT").text()%1) == 0)
							$("#cuentaM").text(canTam[7]+canTam[8]-1);
						else 
							$("#cuentaM").text(canTam[7]+canTam[8]);
						$("#cuentaT").text("0");
					}
				}).fail(function(datos){
					// Por lo general error 0 js xhr
					console.log("Error: "+JSON.stringify(datos));
				}).always(function(){
					// Termina función intermitente y borra datos temporales de base
					clearInterval(rep);
					$.post("php/LSArch.php",{borraTemp:true});
					// Termina todos los procesos pendientes y mata php
					$.ajax({
						type:'POST',
						url:"php/pausa.php",
						data: {"consul":"finPhp"}
					}).done(function(){
						$("#infoProceso").html("Ejecución finalizada con éxito").show();
					}).fail(function(datos){
						console.log("PHP sigue vivo, error al cerrar sesión: "+JSON.stringify(datos));
						$("#infoProceso").removeClass("alert-info").addClass("alert-danger").html("Ocurrió un error al ejecutar o finalizar rutina. Procesos pendientes").show();
					});
					// Botón de regreso que refresca la página
					$("#tablaBotonesProceso").empty().append("<tr><th><button type='button' class='btn btn-warning btn-lg btn-block' id='recPag'>Regresar a ventana <u>p</u>rincipal</button></th></tr>");
					$("#tablaBotonesProceso").on("click", "#recPag", function(){ location.reload();	});
				});
				// Comienza con función intermitente que devuelve movimiento actual
				rep = setInterval(function(){
					revisaRut(1);
				},interm);
			});
			// Botón de pausa de la ventana de proceso, botoncito azul
			$("#ventanaProceso").on("click","#pausaRutina", function(){
				pausaTodo(1, 0);
				// Elimina función intermitente
				clearInterval(rep);
				//Alerta al usuario que se detuvo el sistema
				$("#infoProceso").html("El sistema fue detenido por el usuario").show();
				//Muestra boton de continuar proceso
				$("#continuaRutina").removeAttr("disabled");
				$("#pausaRutina").attr("disabled",true);
			});
			// Continua la rutina actual al presionar botoncito verde
			$("#ventanaProceso").on("click","#continuaRutina", function(){
				pausaTodo(0, 0);
				//Alerta al usuario que se detuvo el sistema
				$("#infoProceso").empty().hide();
				//Muestra boton de continuar proceso
				$("#pausaRutina").removeAttr("disabled");
				$("#continuaRutina").attr("disabled",true);
				// Vuelve a generar intermitente
				rep = setInterval(function(){
					revisaRut(1);
				},interm);
			});
			// Pone botones minis dentro del botón de paro total
			$("#ventanaProceso").on("click","#paroTotal", function(){
				pausaTodo(1, 0);
				clearInterval(rep);
				$("#infoProceso").removeClass("alert-info").addClass("alert-danger");
				$("#infoProceso").html("Sistema en pausa, ¿desea eliminar su progreso actual?").show();
				// Genera los botones
				$("#pausaRutina, #continuaRutina, #paroTotal").attr("disabled",true);
				$(this).parent().append("<button type='button' id='pTsi' class='btn btn-outline-danger btn-md btn-block'><u>S</u>í</button>");
				$(this).parent().append("<button type='button' id='pTno' class='btn btn-outline-danger btn-md btn-block'><u>N</u>o</button>");
			});
			// Al dar sí a fin total, finaliza intermitente y empieza a cerrar php
			$("#ventanaProceso").on("click","#pTsi", function(){
				// Internamente pone paro final y quita pausa
				pausaTodo(1, 1);
				clearInterval(rep);
				$("#pTsi, #pTno").attr("disabled",true);
				$("#infoProceso").removeClass("alert-danger").addClass("alert-info");
				$("#infoProceso").html("Se realizó un paro total del sistema, finalizando rutinas pendientes").show();
			});
			// Al dar no a fin total, regresa botones a la normalidad
			$("#ventanaProceso").on("click","#pTno", function(){
				// Por alguna razón a veces no funciona el trigger pero hace lo mismo
				$("#continuaRutina").removeAttr("disabled").trigger("click");
				// Una vez llamada la función de continuar, quita botones
				$("#pTsi, #pTno").remove();
				$("#pausaRutina, #paroTotal").removeAttr("disabled");
			});
		}
		else
			$("#error").text("No se ha podido conectar a la base de datos del programa").show();
	}).fail(function(){
		$("#error").text("Error interno en javascript. Intente recargando la página").show();
	});
});
