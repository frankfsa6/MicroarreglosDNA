// Variable que evitar perder datos 
var anteVal;
// Inhabilita opciones del selector en los pines para no repetir en varios campos
function InhabPines(){
  $(".ejes option:disabled").each(function(){
    $(this).prop("disabled", false);
  });
  $(".ejes option:selected").each(function(){
    $(".ejes option[value="+$(this).val()+"]").each(function(){
      $(this).prop("disabled", true);
    });
  });
}
// Manda valores calculados a pasos de motores por mm
function pasosMM(){
  var ejes = ["X","Y","Z"];
  for(var i=0; i< ejes.length; i++)
    $("#pasosmm"+ejes[i]).val( (Number($("#pasosRev"+ejes[i]).val())/Number($("#tor"+ejes[i]).val())).toFixed(3) );
}
// Valida las coordenadas introducidas
function valNums(){
  var temp = parseFloat($(this).val());
  if(temp>1000 || !$.isNumeric(temp)){
    $("#error").text("Sólo se aceptan formatos numéricos entre 0 y 1000").show();
    temp = anteVal;
  }
  else
    $("#error").empty().hide();
  $(this).val( temp.toFixed(3) );
}
// Actualiza datos y biblioteca de movimientos
function guardarCfg(){
  var t1 = new Array(), t2 = new Array(), i = 0;
  // Obtiene valores de tabla 1
  $("#t1 tbody").children("tr").each(function(){
    t1[i] = $(this).children("td").first().text();
    var actual = $(this).children("td").first();
    for(var j=0; j<3; j++){
      actual = actual.next();
      t1[i]+=";"+actual.children("input").val();
    }
    i++;
  });
  // Obtiene valores de tabla 2 en pines
  i = 0;
  $(".ejes").each(function(){
    t2[i] = $(this).attr("id")+";"+$(this).parent().parent().parent().children().first().text()+";gpio;"+$(this).find('option:selected').val();
    i++;
  });
  // Obtiene valores de tabla 2 en motores
  $(".selMot").each(function(){
    t2[i] = $(this).attr("id")+";"+$(this).parent().children().first().children().text()+";"+$(this).parent().parent().attr("class")+";"+$(this).find('option:selected').val();
    i++;
  });
  // Manda datos para actualizar base 
  $.post("php/LSArch.php",{uDBConfig:true,"config":t1, "raspberry":t2}, function(){
    $("#info").html("La base de datos ha sido actualizada").show();
  }).fail(function(){
    console.log("Falló actualización de datos");
  });
  //Actualiza el archivo pinesRasp.h
  $.post("php/LSArch.php",{actualizaPines:true});
  // Termina cerrando sesión y saliendo de configuración
  $("#salirConfig").trigger("click");
}
// Oprime botón sin guardar datos
function salirCfg(){
  // Borra la sesión
  $.post("php/LSArch.php",{unsetLogin:true});
  // Pantalla principal para pedir contraseña
  $.post("php/login.php", function(datos){
    $("#error").empty().hide();
    $("#pags").html(datos);
  }).fail(function(){
    $("#info, #pags, #botones").empty()
    $("#info").hide();
    $("#error").text("No se completó la petición de página").show();
  });
}
// Comienza a cargar funciones principales
$(document).ready( function(){
  // Limpia mensajes y aplica filtro
  $("#error, #botones, #info").empty().hide();
  $("#sliX, #sliY, #oriX, #oriY, #oriZ").attr("disabled","true");
  // Detonadas al iniciar o cambiar su valor
  $(".ejes").ready(InhabPines);
  $(".ejes").on("change",InhabPines);
  $(".selMot").ready(pasosMM);
  $(".selMot").on("change",pasosMM);
  // Dispara validación de entrada de datos
  $(".nums").on("change", valNums); 
  $(".nums").on("keydown", function(){
    anteVal = $(this).val();
  });
  // Actualiza valores en retícula
  $("#retX").on("change",function(){
    $("#sliX").val($(this).val());
  });
  $("#retY").on("change","#retY",function(){
    $("#sliY").val($(this).val());
  });
  // Sale sin guardar o actualiza datos
  $("#salirConfig").on("click",salirCfg);
  $("#guardaConfig").on("click", guardarCfg);
});
